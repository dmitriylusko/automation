package helpers;

import java.lang.reflect.Field;

public class FileHelper <T> {



    public Object getFieldValueByFieldName(T obj, String fieldName){
        try {
            Field field = obj.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            return field.get(obj);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

}

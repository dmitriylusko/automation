import helpers.FileHelper;
import org.testng.Assert;
import org.testng.annotations.*;

import static dataproviders.FileDataProvider.*;


@Test
public class FileStorageTest {

    private File file;
    private FileStorage fileStorage;
    private FileHelper<FileStorage> fileHelper = new FileHelper<>();
    private int expected, actual, wrongsize = 0;
    private long start, over;

    @BeforeMethod
    public void initialization () {
        file = new File(NAME_EXAMPLE, CONTENT);
        fileStorage = new FileStorage(STORAGE_SIZE);
    }

    @AfterMethod
    public void tearDown (){
        expected = actual = 0;

    }



    @Test(groups = "FileStorage-tests-pozitive",
            description = "Максимальный размер хранилища: Тест на правильное декларирование поля", priority = 0)
    public void isMaxSizeEqualsToExpected (){
        expected = STORAGE_SIZE; actual = fileStorage.getMaxSize();
        Assert.assertEquals(actual, expected);
    }

    @Test(groups = "FileStorage-tests-pozitive",
            description = "Доступный размер хранилища: Тест на правильное декларирование поля", priority = 1)
    public void isAvailableSizeEqualsToExpected (){
        expected = STORAGE_SIZE; actual = fileStorage.getAvailableSize();
        Assert.assertEquals(actual, expected);
    }

    @Test(groups = "FileStorage-tests-pozitive",
            description = "Конструктор (максимальный размер хранилища): Тест на корректное декларирование поля конструктором ", priority = 2)
    public void isConstructorDefineCorrectMaxSize (){
        expected = STORAGE_SIZE; actual = (Integer) fileHelper.getFieldValueByFieldName(fileStorage,"maxSize");
        Assert.assertEquals(actual, expected);
    }

    @Test(groups = "FileStorage-tests-pozitive",
            description = "Конструктор (доступный размер хранилища): Тест на корректное декларирование поля конструктором", priority = 3)
    public void isConstructorDefineCorrectAvailableSize (){
        expected = STORAGE_SIZE; actual = (Integer) fileHelper.getFieldValueByFieldName(fileStorage, "availableSize");
        Assert.assertEquals(actual, expected);
    }

    @Test(groups = "FileStorage-tests-pozitive", expectedExceptions = FileAlreadyExistsException.class,
            description = "Запись файла в хранилище: Тест на выбрасывание исключительной ситуации 'ileAlreadyExistsException'", priority = 4)
    public void isUnableToAddDuplicates () throws FileAlreadyExistsException {
        fileStorage.write(file); fileStorage.write(file);
    }

    @Test(groups = "FileStorage-tests-pozitive",
            description = "Запись файла в хранилище: Тест на успешное выполнение операции записи", priority = 5)
    public void isFileHaveBeenWritten () throws FileAlreadyExistsException {
        fileStorage.write(file);
        Assert.assertTrue(fileStorage.getFiles().contains(file));
    }

    @Test(groups = "FileStorage-tests-pozitive",
            description = "Файл: Тест на проверку существования файла", priority = 6)
    public void isFileNotExist (){
        Assert.assertFalse(fileStorage.isExists(NAME_EXAMPLE));
    }

    @Test(groups = "FileStorage-tests-pozitive",
            description = "Удаление файла: Тест на проверку удаления файла из хранилища", priority = 7)
    public void isFileHaveBeenDeleted () throws FileAlreadyExistsException {
        fileStorage.delete(NAME_EXAMPLE);
        Assert.assertTrue(fileStorage.getFiles().isEmpty());
    }

    @Test(groups = "FileStorage-tests-pozitive",
            description = "Возврат файла по имени: Тест на проверку корректности возвращаемого файла", priority = 8)
    public void isFileHaveBeenReturned () throws FileAlreadyExistsException {
        fileStorage.write(file);
        Assert.assertEquals(fileStorage.getFile(NAME_EXAMPLE).getFilename(), NAME_EXAMPLE);
    }

    @Test(groups = "FileStorage-tests-pozitive",
            description = "Запись в файл: Тест на проверку времени отработки метода (1800 мс)", priority = 9)
    public void isWriteMethodMakeByNeedTime () throws FileAlreadyExistsException {
        start = System.currentTimeMillis();
        fileStorage.write(file);
        over = System.currentTimeMillis();
        Assert.assertTrue((over - start) >= 1800);
    }

    @Test(groups = "FileStorage-tests-pozitive",
            description = "Допустимый размер хранилища: Тест на корректное изменение размера хранилища после записи файла", priority = 10)
    public void isAvailableSizeCorrectAfterWriting () throws FileAlreadyExistsException {
        expected = fileStorage.getAvailableSize();
        fileStorage.write(file);
        actual = fileStorage.getAvailableSize();
        Assert.assertNotEquals(actual, expected);
    }

    @Test(groups = "FileStorage-tests-negative",
            description = "Допустимый размер хранилища: Тест на корректное изменение размера хранилища после записи файла c длиной контента, равной 1", priority = 11)
    public void isAvalibleSizeDecrementing () throws FileAlreadyExistsException {
        file = new File(NAME_EXAMPLE,"a");
        actual = fileStorage.getAvailableSize();
        fileStorage.write(file);
        expected = fileStorage.getAvailableSize();
        Assert.assertTrue(actual != expected);
    }

    @Test(groups = "FileStorage-tests-negative", expectedExceptions = FileAlreadyExistsException.class,
            description = "Запись дубликатов в файл: Тест на запись дубликатов файл и выбрасывание исключения", priority = 12)
    public void isUnableToAddDuplicateUsingCreationNewFile () throws FileAlreadyExistsException {
        fileStorage.write(new File(NAME_EXAMPLE, CONTENT));
        fileStorage.write(new File(NAME_EXAMPLE, CONTENT));
    }

    @Test(groups = "FileStorage-tests-negative", description = "Максимальный размер хранилища: Тест на проверку декларирования отрицательного и нулевого размера хранилища", priority = 13)
    public void isMaxSizeNotEqualsToIncorrectPassedSize (){
        fileStorage = new FileStorage(wrongsize);
        Assert.assertFalse(fileStorage.getMaxSize() == wrongsize);
    }

    @Test(groups = "FileStorage-tests-negative",
            description = "Запись в файл: Тест на проверку выбрасывания исключения NPE при записи null-content значения", expectedExceptions = NullPointerException.class, priority = 14)
    public void isStorageRejectNullFiles () throws FileAlreadyExistsException {
        fileStorage.write(new File(null," "));
    }

    @Test(groups = "FileStorage-tests-negative",
            description = "Запись в файл: Тест на проверку отказа в записи файла с нулевой длиной контента при заданном нулевом размере хранилища", priority = 15)
    public void isFileRejectNullContentLength () throws FileAlreadyExistsException {
        file = new File(NAME_EXAMPLE,"");
        fileStorage = new FileStorage(0);
        fileStorage.write(file);
        Assert.assertTrue(fileStorage.getFiles().isEmpty());
    }

}

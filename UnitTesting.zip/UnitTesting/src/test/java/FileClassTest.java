import dataproviders.FileDataProvider;
import helpers.FileHelper;
import org.testng.Assert;
import org.testng.annotations.*;

@Test
public class FileClassTest {

    private File file;
    private String expected, actual;
    private double expectedSize, actualSize;
    private FileHelper<File> helper = new FileHelper<>();

    @BeforeMethod(dependsOnGroups = "File-tests-pozitive")
    public void initialization (){
        file = new File(FileDataProvider.NAME_EXAMPLE, FileDataProvider.CONTENT);
    }

    @AfterTest
    public void tearDown(){
        file = null; helper = null;
    }




    @Test(dataProvider = "File.class.data", dataProviderClass = FileDataProvider.class,
            groups = "File-tests-pozitive", description = "Расширение файла: Проверка на возврат правильного расширения файла")
    public void isActualExtensionEqualsExpected (String filename, String content, String extension){
        expected = extension; actual = new File(filename,content).getExtension();
        Assert.assertEquals(actual, expected);
    }

    @Test(dataProvider = "File.class.data", dataProviderClass = FileDataProvider.class,
            groups = "File-tests-pozitive", description = "Размер файла: Тест на правильный расчет размера файла")
    public void isActualSizeEqualsExpected (String filename, String content, String extension){
        expectedSize = Math.rint(content.length()/ (2 * 2)); actualSize = new File(filename, content).getSize();
        Assert.assertEquals(actualSize,expectedSize);
    }

    @Test(dataProvider = "File.class.data", dataProviderClass = FileDataProvider.class,
            groups = "File-tests-pozitive", description = "Контент: Тест на правильную работу метода возврата значения контента")
    public void isActualContentEqualsExpected (String filename, String content, String extension){
        file = new File(filename,content);
        expected = content; actual = file.getContent();
        Assert.assertEquals(actual, expected);
    }

    @Test(dataProvider = "File.class.data", dataProviderClass = FileDataProvider.class,
            groups = "File-tests-pozitive", description = "Имя файла: Тест на правильную работу метода возврата имени файла")
    public void isActualNameEqualsExpected (String filename, String content, String extension){
        expected = filename; actual= new File(filename,content).getFilename();
        Assert.assertEquals(actual, expected);
    }

    @Test(groups = "File-tests-pozitive", description = "Конструктор (имя файла): Тест на правильное декларирование поля конструктором",
            dataProvider = "File.class.data", dataProviderClass = FileDataProvider.class)
    public void isConstructorDefineFilenameCorrectly (String filename, String content, String extension){
        actual = (String) helper.getFieldValueByFieldName(new File(filename, content), "filename");
        expected = filename;
        Assert.assertEquals(actual, expected);
    }

    @Test(groups = "File-tests-pozitive", description = "Конструктор (контент): Тест на правильное декларирование поля конструктором",
            dataProvider = "File.class.data", dataProviderClass = FileDataProvider.class)
    public void isConstructorDefineContentCorrectly (String filename, String content, String extension){
        actual = (String) helper.getFieldValueByFieldName(new File(filename, content), "content");
        expected = content;
        Assert.assertEquals(actual, expected);
    }

    @Test(expectedExceptions = {NullPointerException.class, IllegalStateException.class},
            groups = "File-tests-negative", description = "Имя файла и контент: Тест на обработку исключений при передаче пустых значений в поля")
    public void isFileNotAcceptNullValues () throws NullPointerException, IllegalStateException{
        file = new File(null,null);
        file.getContent();
        file.getFilename();
    }

    @Test(dataProvider = "File.class.data", dataProviderClass = FileDataProvider.class,
            groups = "File-tests-negative", description = "Контент: Тест на неизменность поля после вызова других методов")
    public void isReturnedContentEqualsActualAfterCalling (String filename, String content, String extension){
        file = new File(filename,content);
        file.getExtension();
        actual = file.getContent(); expected = content;
        Assert.assertEquals(actual,expected);
    }

    @Test(groups = "File-tests-negative",
            description = "Имя файла: Тест возможности записи запрещенных символов")
    public void isFileNotAcceptForbiddenSymbols (){
        file = new File(FileDataProvider.SYMBOL_FOR_CHECK,FileDataProvider.CONTENT);
        Assert.assertFalse(file.getFilename().contains(FileDataProvider.SYMBOL_FOR_CHECK));
    }

}

package dataproviders;

import org.testng.annotations.DataProvider;

public class FileDataProvider {


    public static final String SYMBOL_FOR_CHECK = "⌚.doc";
    public static final String NAME_EXAMPLE = "'Testing DOT COM' Roman Savin", CONTENT = "book";
    public static final int STORAGE_SIZE = 50;

    @DataProvider(name = "File.class.data")
    public static Object[][] data1 (){
        return new Object[][]{
                {"pom.xml","configuration file","xml"},
                {"Documentation.gzip", "Gnu Zipped File", "gzip"},
                {"БД2019.accdb", "Access 2007 Database File", "accdb"},
                {"apache_maven-3.6.1-bin.tar.gz", "binary distribution archive", "tar.gz"},
                {"Тестирование ДОТ КОМ(1).doc", "техническая литература", "doc"},
        };
    }
}
